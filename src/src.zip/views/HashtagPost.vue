<template>
  <div id="overflow-page">
    <HomeNav id="navHome" />
    <vue-element-loading
      :active="getLoadStatus"
      is-full-screen
      size="80"
      background-color="rgba(0, 0, 0, 0.3)"
      color="#fff"
      spinner="bar-fade-scale"
    />
    <div id="content">
      <HashBackBar :status ='$route.params.sentiment'/>
      <div class="mb-3 text-right">
        <button id="export-btn" @click="printWindow()">
          <i class="fa fa-print fa-2x" /> 
          <b> Print</b>
        </button>
      </div>
      <b-container>
        <back-to-top bottom="50px" right="50px">
          <button type="button" class="btn btn-to-top">
            <i class="fa fa-chevron-up"></i>
          </button>
        </back-to-top>
        <HashPost :sentimentHash='$route.params.sentiment' :social='$route.params.source'/>
      </b-container>
    </div>
  </div>
</template>

<script>
import HomeNav from '@/components/HomeNav.vue';
import HashPost from '@/components/wordcloud/HashPost.vue';
import VueElementLoading from "vue-element-loading";
import HashBackBar from '@/components/wordcloud/HashBackBar.vue';
import { mapGetters } from "vuex";

export default {
  components: {
    HomeNav,
    HashPost,
    VueElementLoading,
    HashBackBar
  },
  props: {
    datas: {
      type: Object
    },
    source: {
      type: String
    },
    sentiment: {
      type: Number
    }
  },
  computed: {
    ...mapGetters([
      "getLoadStatus",
    ]),
  },
  methods: {
    printWindow: function() {
      try {
        window.print();
      } catch (err) {
        console.log(err);
      }
    },
  }
}
</script>

<style scoped>
#export-btn{
  margin: 0px 20px;
  color: #495057;
  background-color: #e9ecef;
  border-color: #e9ecef;
  border-radius: 9px;
  box-shadow: 0 2px 5px 0 rgb(0 0 0 / 20%);  
}
#export-btn:hover{
  color: white;
    background-color: #495057;
    border-color:  #495057;
}
button {
  background-color: #f0f0f0;
  border: solid 1px #bbb;
  padding: 10px;
  font-size: 15px;
  border-radius: 5px;
}
.btn-to-top {
  width: 60px;
  height: 60px;
  padding: 10px 16px;
  border-radius: 50%;
  font-size: 22px;
  line-height: 22px;
  background-color: #fed16e;
  border-color: #fed16e;
  color: #fff;
  box-shadow: 2px 1px 4px #888888;
}
.btn-to-top:hover{
  background-color: #f7c24e;
  border-color: #f7c24e;
  color: #fff;
}
#content {
  max-width: 93%;
  margin: auto;
  background: white;
  min-height: 100vh;
  padding: 0;
  padding-bottom: 40px;
}
@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: portrait) {
  #overflow-page {
    overflow: hidden;
  }
}
@media only screen and (min-width: 0px) and (max-width: 600px) {
  #overflow-page {
    overflow: hidden;
  }
  .btn-to-top {
    width: 47px;
    height: 47px;
    padding: 10px 10px;
    border-radius: 50%;
    font-size: 22px;
    line-height: 22px;
}
  .vue-back-to-top{
      bottom: 50px !important;
      right: 17px !important;
  }
}
</style>