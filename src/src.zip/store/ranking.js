import { RankingService } from "@/common/api.services";
export default {
  state: {
    arrDefault:null,
    arrDateRank:null,
    dataTrend:[],
    showRankTab:true,
    showWordList:true,
    detailPostRanking:[],
    submit: false,
    domain: [],
    results: [],
    resultssdm: [],
    objectname: [],
    obname: [],
    trendranking: [],
    social: [],
    subdomain: [],
    sentimentdetailranking: [],
    sentimentstat: {
      total: {
        post: 0,
        comment: 0,
        users: 0,
        total_sentiments: {
          positive: 0,
          neutral: 0,
          negative: 0,
        },
      },
      facebook: {
        post: 0,
        comment: 0,
        users: 0,
        total_sentiments: {
          positive: 0,
          neutral: 0,
          negative: 0,
        },
      },
      twitter: {
        post: 0,
        comment: 0,
        users: 0,
        total_sentiments: {
          positive: 0,
          neutral: 0,
          negative: 0,
        },
      },
      pantip: {
        post: 0,
        comment: 0,
        users: 0,
        total_sentiments: {
          positive: 0,
          neutral: 0,
          negative: 0,
        },
      },
      instagram: {
        post: 0,
        comment: 0,
        users: 0,
        total_sentiments: {
          positive: 0,
          neutral: 0,
          negative: 0,
        },
      },
      youtube: {
        post: 0,
        comment: 0,
        users: 0,
        total_sentiments: {
          positive: 0,
          neutral: 0,
          negative: 0,
        },
      },
      news: {
        post: 0,
        comment: 0,
        users: 0,
        total_sentiments: {
          positive: 0,
          neutral: 0,
          negative: 0,
        },
      },
    },
    sentimentranking: [],
    sentimentrankingchart: [],
    sentimentrankingall: 0,
    sentimentrankingfacebook: 0,
    sentimentrankingtwitter: 0,
    sentimentrankingpantip: 0,
    sentimentrankingyoutube: 0,
    sentimentrankinginstagram: 0,
    sentimentrankingnews: 0,
    sentimentobjdata: [],
    data: [
      // {
      //   count: 229,
      //   name: "ทหารภัยพิบัติ"
      // },
      // {
      //   count: 119,
      //   name: "นางสาววาสนา นาน่วม"
      // },
      // {
      //   count: 32,
      //   name: "อาวุธปืนเล็กและอาวุธสนับสนุน"
      // },
      // {
      //   count: 18,
      //   name: "สมัครนักเรียนทหาร"
      // },
      // {
      //   count: 10,
      //   name: "ทหารจิตอาสา"
      // },
      // {
      //   count: 9,
      //   name: "ทหารปฏิวัติ"
      // },
      // {
      //   count: 8,
      //   name: "การลักลอบเข้าประเทศ"
      // },
      // {
      //   count: 7,
      //   name: "พล.อ.ณรงค์พันธ์ จิตต์แก้วแท้"
      // },
      // {
      //   count: 6,
      //   name: "เกณฑ์ทหาร"
      // },
      // {
      //   count: 3,
      //   name: "พลโท เกรียงไกร ศรีรักษ์"
      // }
    ],
  },
  getters: {
    getArrDefault: (state) => {
      return state.arrDefault;
    },
    getArrDateRank: (state) => {
      return state.arrDateRank;
    },
    getDataTrend: (state) => {
      return state.dataTrend;
    },
    getShowRankTab: (state) => {
      return state.showRankTab;
    },
    getShowWordList: (state) => {
      return state.showWordList;
    },
    getDomainRanking: (state) => {
     let domain = state.results.filter(element => element.display ==true);
      return domain.map((result) => {
        return result.name;
      });
    },
    getShowSubDomainRanking: (state) => {
      let data = state.resultssdm.filter((v)=>v.display)
      return data.map((x)=>x.name)
    },
    // getSubDomainRanking: (state) => {
    //   return state.results;
    // },
    getSubmitRanking: (state) => {
      return state.submit;
    },
    getSocial: (state) => {
      return state.social;
    },
    getRanking: (state) => {
      return state.data;
    },
    getTrendRanking: (state) => {
      return state.trendranking;
    },
    getObjectName: (state) => {
      return state.objectname;
    },
    getObName: (state) => {
      return state.obname;
    },
    getSubDomain: (state) => {
      return state.subdomain;
    },
    getSentimentDetailRanking: (state) => {
      return state.sentimentdetailranking;
    },
    getSentimentStat: (state) => {
      return state.sentimentstat;
    },
    getSentimentRanking: (state) => {
      return state.sentimentranking;
    },
    getSentimentRankingChart: (state) => {
      return state.sentimentrankingchart;
    },
    getSentimentRankingAll: (state) => {
      return state.sentimentrankingall;
    },
    getSentimentRankingFacebook: (state) => {
      return state.sentimentrankingfacebook;
    },
    getSentimentRankingTwitter: (state) => {
      return state.sentimentrankingtwitter;
    },
    getSentimentRankingPantip: (state) => {
      return state.sentimentrankingpantip;
    },
    getSentimentRankingYoutube: (state) => {
      return state.sentimentrankingyoutube;
    },
    getSentimentRankingInstagram: (state) => {
      return state.sentimentrankinginstagram;
    },
    getSentimentRankingNews: (state) => {
      return state.sentimentrankingnews;
    },
    getSentimentObjData: (state) => {
      return state.sentimentobjdata;
    },
    getDetailPostRanking: (state) => {
      return state.detailPostRanking ;
    },
  },
  mutations: {
    setArrDefault: (state,payload) => {
    state.arrDefault=payload;
    },
    setArrDateRank: (state,payload) => {
      state.arrDateRank=payload;
    },
    setDataTrend: (state, payload) => {
     state.dataTrend=payload;
    },
    setShowRankTab: (state, payload) => {
     state.showRankTab= payload;
    },
    setShowWordList: (state, payload) => {
     state.showWordList = payload;
    },
    setDomainRanking: (state, payload) => {
      state.results = payload;
    },
    setSubDomainRanking: (state, payload) => {
      state.resultssdm = payload;
    },
    setSubmitRanking: (state, payload) => {
      state.submit = payload;
    },
    setSocial: (state, payload) => {
      state.social = payload;
    },
    changeDataChoice: (state, payload) => {
      state.dateChoice = payload.choice;
    },
    setRanking: (state, payload) => {
      state.data = payload;
    },
    setTrendRanking: (state, payload) => {
      state.trendranking = payload;
    },
    setObjectName: (state, payload) => {
      state.objectname = payload;
    },
    setObName: (state, payload) => {
      state.obname = payload;
    },
    setSubDomain: (state, payload) => {
      state.subdomain = payload;
    },
    setSentimentDetailRanking: (state, payload) => {
      state.sentimentdetailranking = payload;
    },
    setSentimentStat: (state, payload) => {
      state.sentimentstat = payload;
    },
    setSentimentRanking: (state, payload) => {
      state.sentimentranking = payload;
    },
    setSentimentRankingChart: (state, payload) => {
      state.sentimentrankingchart = payload;
    },
    setSentimentRankingAll: (state, payload) => {
      state.sentimentrankingall = payload;
    },
    setSentimentRankingFacebook: (state, payload) => {
      state.sentimentrankingfacebook = payload;
    },
    setSentimentRankingTwitter: (state, payload) => {
      state.sentimentrankingtwitter = payload;
    },
    setSentimentRankingPantip: (state, payload) => {
      state.sentimentrankingpantip = payload;
    },
    setSentimentRankingYoutube: (state, payload) => {
      state.sentimentrankingyoutube = payload;
    },
    setSentimentRankingInstagram: (state, payload) => {
      state.sentimentrankinginstagram = payload;
    },
    setSentimentRankingNews: (state, payload) => {
      state.sentimentrankingnews = payload;
    },
    setSentimentObjData: (state, payload) => {
      state.sentimentobjdata = payload;
    },
    setDetailPostRanking: (state, payload) => {
      state.detailPostRanking = payload;
    },
  },
  actions: {
    async fetchDomainRanking({ commit }) {
      commit("setLoadStatus", true);
      try {
        const res = await RankingService.getDomainRanking({ limit: 100000 });
        commit("setDomainRanking", res.data.results);
        commit("setLoadStatus", false);
      } catch (error) {
        console.log(error);
      }
    },
    async fetchSubDomainRanking({ commit }, payload) {
      commit("setLoadStatus", true);
      try {
        const res = await RankingService.getSubDomainRanking(payload);
        commit("setSubDomainRanking", res.data.results);
        commit("setLoadStatus", false);
        // console.log('test',res.data.results.name);
      } catch (error) {
        console.log(error);
      }
    },
   async fetchRanking({ commit }, payload) {
  commit("setLoadStatus", true);
  try {
    const res = await RankingService.getRanking(payload);

    // Ranking list (as before)
    commit("setRanking", res?.data?.data ?? []);

    const trend = Array.isArray(res?.data?.trend) ? res.data.trend : [];
    if (!trend.length) {
      // No trend data: clear and inform
      commit("setDataTrend", []);
      commit("setTrendRanking", [["Date"]]);
      alert("ไม่มีข้อมูล");
      return;
    }

    // Normalize series & guard against missing fields
    const normalized = trend.map((s, i) => ({
      label: s?.label ?? `Series ${i + 1}`,
      x: Array.isArray(s?.x) ? s.x : [],
      y: Array.isArray(s?.y) ? s.y : [],
    }));

    commit("setDataTrend", normalized);

    // Build unified X-axis (all unique x values across series)
    const xSet = new Set();
    for (const s of normalized) for (const xi of s.x) xSet.add(String(xi));
    const xAxis = Array.from(xSet).sort(); // sort if x are date strings

    if (!xAxis.length) {
      commit("setTrendRanking", [["Date", ...normalized.map(s => s.label)]]);
      alert("ไม่มีข้อมูล");
      return;
    }

    // Build per-series lookup maps: x -> y
    const seriesMaps = normalized.map(s => {
      const m = Object.create(null);
      for (let i = 0; i < s.x.length; i++) {
        const key = String(s.x[i]);
        const val = Number.isFinite(Number(s.y?.[i])) ? Number(s.y[i]) : 0;
        m[key] = val;
      }
      return m;
    });

    const labels = normalized.map(s => s.label);

    // Assemble result table: header + rows
    const table = [
      ["Date", ...labels],
      ...xAxis.map(x => [x, ...seriesMaps.map(m => m[x] ?? 0)]),
    ];

    commit("setTrendRanking", table);
  } catch (error) {
    console.log(error);
    alert("ไม่มีข้อมูล");
  } finally {
    commit("setLoadStatus", false);
  }
}
,
    async fetchSentimentStat({ commit, state }, payload) {
      commit("setLoadRankTab", true);
      try {
        const res = await RankingService.getSentimentStat(payload);
        commit("setSentimentStat", res.data);
        // commit("setLoadStatus", false);

        console.log("ddd", res.data);
        console.log("newss", state.data);

        let result = ["Socials", "Users"];

        let fbpie = res.data.facebook.users;
        let twpie = res.data.twitter.users;
        let igpie = res.data.instagram.users;
        let ptpie = res.data.pantip.users;
        let nwpie = res.data.news.users;
        let ytpie = res.data.youtube.users;

        let temp = [];
        temp.push(
          ["facebook", fbpie],
          ["Twitter", twpie],
          ["Instagram", igpie],
          ["Pantip", ptpie],
          ["News", nwpie],
          ["Youtube", ytpie]
        );
        commit("setSentimentRankingChart", [result, ...temp]);

        console.log('5555',[result, ...temp]);

        // let keep = ["Positive", "Neutral", "Negative"]
        let all = res.data.total.total_sentiments;
        commit("setSentimentRankingAll", all);
        commit("setSentimentRankingFacebook", res.data.facebook.total_sentiments);
        commit("setSentimentRankingTwitter", res.data.twitter.total_sentiment);
        commit("setSentimentRankingPantip", res.data.pantip.total_sentiments);
        commit("setSentimentRankingYoutube", res.data.youtube.total_sentiments);
        commit("setSentimentRankingInstagram", res.data.instagram.total_sentiments);
        commit("setSentimentRankingNews", res.data.news.total_sentiments);

        commit("setLoadRankTab", false);
      } catch (error) {
        console.log(error);
      }
    },
    async fetchSentimentDetailRanking({ commit }, payload) {
      commit("setLoadRankPost", true);
      try {
        const res = await RankingService.getSentimentDetailRanking(payload);
        var post = res.data.data
        var pair = {read: true};   
        var posts= post.map((result) => {
        return {...result, ...pair}
      });
        commit("setSentimentDetailRanking", res.data);
        commit("setDetailPostRanking",posts)
        console.log(posts);
        commit("setLoadRankPost", false);
      } catch (error) {
        console.log(error);
        commit('setLoadRankPost', false );
        alert("ไม่มีข้อมูล");
      }
    },
  },
};
