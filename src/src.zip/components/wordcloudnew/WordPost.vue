<template>
  <div>
    <div class="mt-md-1 ">
      <!-- <div class="my-4 text-left">
        <h4 class="bold text-lg-left text-md-left">All Posts</h4>
      </div> -->
      <div class="mt-1  text-left">
        <span class="h5 bold">
          <i class="fa fa-tag mr-2" aria-hidden="true"></i>{{ querySearch }}
        </span>
      </div>
      <b-card class="card-platform">
        <!-- {{ datachart }} -->
        <div class="text-left text-tt mb-2 h6 " style="letter-spacing: 1.5px;">Total <span class="h6 bold">{{
          datachart.count
          | numFormat }}</span>
          Posts</div>
        <b-row>
          <b-col cols="12" lg="5">
            <div>
              <b-row md="5" style="font-size:16px">
                <b-col v-b-tooltip.hover :title="platform.Accounts + ' accounts'">
                  <i class="fa fa-users mr-1" aria-hidden="true"></i>
                  <div >
                    {{ platform.Accounts | shortNumber }}
                  </div>
                </b-col>

                <b-col  v-b-tooltip.hover :title="platform.totalPost + ' posts'">
                  <i class="fa fa-paper-plane mr-1" />
                  <div>
                    {{ platform.totalPost | shortNumber }}
                  </div>
                </b-col>

                <b-col v-b-tooltip.hover :title="platform.comments_count + ' comments'">
                  <i class="fa fa-comments mr-1" aria-hidden="true"></i>
                  <div >
                    {{ platform.comments_count | shortNumber }}
                  </div>
                </b-col>

                <b-col v-b-tooltip.hover :title="platform.likes_count + ' likes'">
                  <i class="fa fa-thumbs-o-up mr-1" aria-hidden="true"></i>
                  <div >
                    {{ platform.likes_count | shortNumber }}
                  </div>
                </b-col>

                <b-col v-b-tooltip.hover :title="platform.retweets_count + ' reposts'">
                  <i class="fa fa-retweet mr-1" aria-hidden="true"></i>
                  <div >
                    {{ platform.retweets_count | shortNumber}}
                  </div>
                </b-col>

              </b-row>
            </div>
            <!-- {{ platform }} -->
            <!-- {{ datachart.total }} -->
            <SentimentBar :positive="datachart.positive || 0" :neutral="datachart.neutral || 0"
              :negative="datachart.negative || 0" class="py-2" />
          </b-col>
          <b-col cols="">
            <b-row cols="5" class="mx-auto " v-if="platform && Object.keys(platform).length">
              <!-- Facebook -->
              <b-col>
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/cfb.png" class="img-issue" />
                        <!-- {{ platform.facebook | numFormat}} -->
                      </div>
                      <div class="h6l">
                        {{ platform.facebook | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>

                    </div>
                  </b-col>
                </b-row>
              </b-col>

              <!-- Twitter -->
              <b-col>
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/ctw.png" class="img-issue" />
                        <!-- {{ platform.facebook | numFormat}} -->
                      </div>
                      <div class="h6">
                        {{ platform.twitter | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>

                    </div>
                  </b-col>
                </b-row>
              </b-col>

              <!-- Instagram -->
              <b-col>
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/cig.png" class="img-issue" />
                      </div>
                      <div class="h6">
                        {{ platform.instagram | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>

                    </div>
                  </b-col>
                </b-row>
              </b-col>

              <!-- Pantip -->
              <b-col>
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/cpt.png" class="img-issue" />
                      </div>
                      <div class="h6">
                        {{ platform.pantip | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>

                    </div>
                  </b-col>
                </b-row>
              </b-col>

              <!-- YouTube -->
              <b-col>
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/cyt.png" class="img-issue" />
                      </div>
                      <div class="h6">
                        {{ platform.youtube | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>

                    </div>
                  </b-col>
                </b-row>
              </b-col>

              <!-- News -->
              <b-col class="my-2">
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/cn.png" class="img-issue" />
                      </div>
                      <div class="h6">
                        {{ platform.news | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>

                    </div>
                  </b-col>
                </b-row>
              </b-col>

              <!-- TikTok -->
              <b-col>
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/tt.png" class="img-issue" />
                      </div>
                      <div class="h6">
                        {{ platform.tiktok | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>
                    </div>
                  </b-col>
                </b-row>
              </b-col>

              <!-- Blockdit -->
              <b-col>
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/Block.png" class="img-issue" />
                      </div>
                      <div class="h6">
                        {{ platform.blockdit | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>
                    </div>
                  </b-col>
                </b-row>
              </b-col>

              <!-- Threads -->
              <b-col>
                <b-row>
                  <b-col cols="12">
                    <div class="text-center">
                      <div class="h5">
                        <img src="@/assets/ctd.png" class="img-issue" />
                      </div>
                      <div class="h6">
                        {{ platform.threads | numFormat }}
                        <span style="font-size: small;letter-spacing: 1.5px;">posts</span>
                      </div>
                    </div>
                  </b-col>
                </b-row>
              </b-col>
            </b-row>

          </b-col>
        </b-row>
        <PlatformBarChart :platform="platform" v-if="platform && Object.keys(platform).length" class="py-0 " />

      </b-card>

      <!-- <PlatformBarChart :platform="platform" v-if="platform" /> -->

      <b-row class="mb-1 w-100 ">
        <b-col cols="7" md="6" lg="6" class="my-1 m-auto">
          <div class="bold text-lg-left text-md-left h6">
            All Posts | {{ querySearch }}
          </div>
        </b-col>
        <b-col cols="5" md="6" lg="6" class="m-auto my-1 text-right">
          <span id="post-comment">
            <i class="far fa-paper-plane" />

            <b>
              <span v-if="datacount !== 0"> {{ datacount | numFormat }} </span><span v-else> 0 </span></b>
            โพสต์
          </span>
        </b-col>
      </b-row>

      <b-row class="">
        <b-col sm="12" md="auto">
          <b-form-radio-group v-model="selected" :options="options" name="radio-inline" class="mt-1 mb-2 text-left ml-2"
            @change="selectSentiment"></b-form-radio-group>
        </b-col>
        <b-col md="">
          <b-form-select :options="itemSocial" v-model="select_social" @change="selectSort" id="search-input" size="sm"
            class="mb-2 select-sort" placeholder="Select Platform"></b-form-select>
        </b-col>
        <b-col sm="12" md="" class="text-right">

          <b-form-select v-model="sort" :options="optionSort" size="sm" class="mb-2 select-sort"
            @change="selectSort"></b-form-select>
        </b-col>
      </b-row>
    </div>

    <div>
      <vue-element-loading :active="load" size="80" background-color="rgba(255, 255, 255, 0.5)" color="#b6ac9a" />
      <!-- Highlight -->
      <b-form-checkbox switch size="lg" class="text-right mb-2" v-model="checked">
        <span :style="myStyle" v-if="checked" class="box-hl pl-2 pr-2">Highlight</span>
        <span v-else class="box-hl pl-2 pr-2">Highlight</span>
      </b-form-checkbox>
      <div v-if="this.dataIssue == ''" class="md-font">
        <b-card>
          <div class="mt-3">ไม่พบข้อมูล</div>
        </b-card>
      </div>
      <b-card no-body class="overflow-hidden" header-tag="header" footer-tag="footer"
        style="max-width: 100%; margin-bottom: 30px" v-for="(datas, k) in dataIssue" :key="k">
        <template #header>
          <b-row>
            <b-col style="text-align: initial; display: contents">
              <span v-if="datas.profile_image">
                <b-avatar @error="user" size="47px" :src="datas.profile_image" loading="lazy" class="imgpro"
                  v-if="datas.source != 'blockdit'"></b-avatar>
                <b-avatar @error="user" size="47px" :src="datas.profile_image" loading="lazy" v-else></b-avatar>
              </span>
              <span v-else> <b-avatar size="45px"></b-avatar></span>
              <img v-if="datas.source === 'twitter'" :src="imgtw" class="social-img" />
              <img v-if="datas.source === 'facebook'" :src="imgfb" class="social-img" />
              <span v-if="datas.source == 'pantip'">
                <img v-if="datas.platform == 'dek-d'" src="@/assets/dekd.png" class="social-img" />
                <img v-else-if="datas.platform == 'lemon8'" src="@/assets/lemon8.png" class="social-img" />
                <img v-else src="@/assets/Pantip.png" class="social-img" />
              </span>
              <img v-if="datas.source === 'youtube'" :src="imgyt" class="social-img" />
              <img v-if="datas.source === 'news'" :src="imgnw" class="social-img" />
              <img v-if="datas.source === 'instagram'" :src="imgig" class="social-img" />
              <img v-if="datas.source === 'blockdit'" :src="imgbd" class="social-img" />
              <img v-if="datas.source === 'tiktok'" src="@/assets/Tiktok.png" class="social-img" />
              <img v-if="datas.source === 'threads'" src="@/assets/Threads.png" class="social-img" />
            </b-col>
            <b-col style="text-align: initial">
              <!-- {{username(datas.account_name)}} -->
              <span id="user-name">
                <b>{{ datas.account_name }}</b>
                <a v-if="datas.url_post && datas.url_post.includes('mbasic')"
                  v-bind:href="datas.url_post.replace('mbasic.', '')" class="fa fa-external-link" target="_blank"></a>
                <a v-else v-bind:href="datas.url_post" class="fa fa-external-link" target="_blank"></a>
              </span>

              <!-- Time -->
              <div id="text-date" style="text-align: start" class="md-font">
                <span v-if="datas.date">{{ datas.date.split("T")[0] }} |
                  {{ datas.date.split("T")[1] }}</span>
              </div>
            </b-col>
            <b-col sm="12" md="4" class="text-md-right mr-2">
              <div>
                <img class="images1 d-none" :src="datas.snapshot" />
                <i v-if="datas.snapshot" class="fas fa-camera mr-2" @click="onClick(0, [datas.snapshot])" />
                <span v-if="datas.user_sentiment">
                  <span v-if="
                    datas.user_sentiment[objId] == 0 ||
                    datas.user_sentiment[objId]
                  ">
                    <b-button-group size="sm" id="btn-group" v-if="datas.user_sentiment[objId] == 1">
                      <b-button id="btn-pos" :style="btnPosStyle"
                        @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                      <b-button id="btn-nue" @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                      <b-button id="btn-neg" @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                    </b-button-group>
                    <b-button-group size="sm" id="btn-group" v-if="datas.user_sentiment[objId] == 0">
                      <b-button id="btn-pos" @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                      <b-button id="btn-nue" :style="btnNeuStyle"
                        @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                      <b-button id="btn-neg" @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                    </b-button-group>
                    <b-button-group size="sm" id="btn-group" v-if="datas.user_sentiment[objId] == -1">
                      <b-button id="btn-pos" @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                      <b-button id="btn-nue" @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                      <b-button id="btn-neg" :style="btnNegStyle"
                        @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                    </b-button-group>
                  </span>
                  <span v-else>
                    <b-button-group size="sm" id="btn-group" v-if="datas.sentiment == 1">
                      <b-button id="btn-pos" :style="btnPosStyle"
                        @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                      <b-button id="btn-nue" @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                      <b-button id="btn-neg" @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                    </b-button-group>
                    <b-button-group size="sm" id="btn-group" v-if="datas.sentiment == 0">
                      <b-button id="btn-pos" @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                      <b-button id="btn-nue" :style="btnNeuStyle"
                        @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                      <b-button id="btn-neg" @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                    </b-button-group>
                    <b-button-group size="sm" id="btn-group" v-if="datas.sentiment == -1">
                      <b-button id="btn-pos" @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                      <b-button id="btn-nue" @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                      <b-button id="btn-neg" :style="btnNegStyle"
                        @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                    </b-button-group>
                  </span>
                </span>
                <span v-else>
                  <b-button-group size="sm" id="btn-group" v-if="datas.sentiment == 1">
                    <b-button id="btn-pos" :style="btnPosStyle"
                      @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                    <b-button id="btn-nue" @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                    <b-button id="btn-neg" @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                  </b-button-group>
                  <b-button-group size="sm" id="btn-group" v-if="datas.sentiment == 0">
                    <b-button id="btn-pos" @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                    <b-button id="btn-nue" :style="btnNeuStyle"
                      @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                    <b-button id="btn-neg" @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                  </b-button-group>
                  <b-button-group size="sm" id="btn-group" v-if="datas.sentiment == -1">
                    <b-button id="btn-pos" @click="getTheSelected(k, 1, datas.uid)">Positive</b-button>
                    <b-button id="btn-nue" @click="getTheSelected(k, 0, datas.uid)">Neutral</b-button>
                    <b-button id="btn-neg" :style="btnNegStyle"
                      @click="getTheSelected(k, -1, datas.uid)">Negative</b-button>
                  </b-button-group>
                </span>
              </div>
            </b-col>
          </b-row>
        </template>
        <b-row no-gutters>
          <b-col lg="12">
            <b-card-body>
              <b-card-text class="box-contents">
                <div v-if="datas && datas.news_info && datas.news_info.source_news == 'external'"
                  class="info-news text-right my-1 small ">
                  <span v-if="datas.news_info.source_news == 'external'">ข่าวต่างประเทศ</span>
                  | <span v-if="datas.news_info.nation">{{ datas.news_info.nation }}</span>
                </div>
                <div v-if="datas && datas.title" class="title-news text-left my-2">
                  {{ datas.title }}
                </div>

                <!-- <Highlighter
                  class="my-highlight md-font"
                  :style="{
                    textAlign: 'left',
                    fontSize: '17px',
                    padding: '10px',
                  }"
                  highlightClassName="highlight4"
                  :searchWords="highlightText(datas.hottopic_docs.keywords)"
                  :autoEscape="true"
                  :textToHighlight="
                    datas.read ? datas.full_text.slice(0, 450) : datas.full_text
                  "
                ></Highlighter> -->
                <Highlighter class="my-highlight md-font" :style="{
                  textAlign: 'left',
                  fontSize: '17px',
                  padding: '10px',
                }" highlightClassName="highlight4" :searchWords="highlightText(datas.full_text)" :autoEscape="true"
                  :textToHighlight="datas.read ? datas.full_text.slice(0, 450) : datas.full_text
                    "></Highlighter>

                <div v-if="datas.full_text.length > 450" @click="datas.read = !datas.read" id="readmore">
                  <span v-if="datas.read == true">... อ่านต่อ</span><span v-else>ย่อบทความ</span>
                </div>
                <!-- </read-more> -->
              </b-card-text>
            </b-card-body>
          </b-col>
          <b-col>
            <div v-if="datas.source == 'tiktok' && datas.uid">
              <a v-bind:href="datas.url_post" target="_blank">
                <img :src="datas.photos && datas.photos[0]" onerror="this.style.display='none'"
                  style="height:450px;border-radius: 10px;" class="my-3" />
                <!-- <lite-tiktok :videoid="datas.uid" style=" pointer-events: none; "></lite-tiktok> -->
              </a>

              <!-- <iframe
                width="auto"
                height="750"
                :src="'https://www.tiktok.com/embed/v2/' + datas.uid"
                allowfullscreen
              ></iframe> -->
            </div>
            <div id="photo-grid" v-if="
              datas.photos !== null &&
              datas.photos &&
              datas.photos != '' &&
              datas.photos != '' &&
              datas.source !== 'tiktok'
            " class="mb-4">
              <div v-if="typeof datas.photos == 'string'">
                <img class="images1" :src="datas.photos" @click="onClick(0, [datas.photos])"
                  onerror="this.style.display='none'" />
              </div>
              <div v-else>
                <div v-if="datas.photos.length == 1" class="p-20">
                  <img class="d-none images1" v-for="(image, i) in datas.photos" :src="datas.photos"
                    @click="onClick(i, datas.photos)" :key="i" />
                  <img class="images1" v-for="(image, i) in datas.photos" :src="datas.photos"
                    @click="onClick(i, datas.photos)" :key="`A-${i}`" onerror="this.style.display='none'" />
                </div>
                <div v-else-if="datas.photos.length == 2" class="p-20">
                  <img class="images2" v-for="(image, i) in datas.photos" :src="image" @click="onClick(i, datas.photos)"
                    :key="`B-${i}`" onerror="this.style.display='none'" />
                </div>
                <div v-else-if="datas.photos.length == 3" class="p-20">
                  <img class="images3" v-for="(image, i) in datas.photos" :src="image" @click="onClick(i, datas.photos)"
                    :key="`C-${i}`" onerror="this.style.display='none'" />
                </div>
                <div v-else class="p-20 col2">
                  <img class="images4" v-for="(image, i) in datas.photos.slice(0, 4)" :src="image"
                    @click="onClick(i, datas.photos)" :key="`D-${i}`" onerror="this.style.display='none'" />
                  <div v-if="datas.photos.length > 4" id="picmore" @click="onClick(3, datas.photos)"
                    onerror="this.style.display='none'">
                    +{{ datas.photos.length - 4 }}
                  </div>
                </div>
              </div>
              <vue-gallery-slideshow :images="dataPhoto" :index="index" @close="index = null"></vue-gallery-slideshow>
            </div>
          </b-col>
        </b-row>
        <div class="text-left ai-box my-2 px-2" v-if="datas && datas.photos_text && datas.photos_text.length"
          style="font-size: 15px;font-weight: 500;">
          <div v-for="(text, idx) in datas.photos_text">

            <div v-if="text && text.length">
              <b-avatar size="20px" style="font-size: 12px;background-color:#4e6175;" class="mr-2">{{ idx
                + 1 }}
              </b-avatar>
              <span style="background-color: #e5e5e5;border-radius: 50%;width: 10px;height: 6px;">
              </span>
              <b-icon icon="textarea-t" scale="1.3"></b-icon> OCR :
              {{ text }}
            </div>
            <div v-if="text.face">
              <span v-for="(face, idx) in text.face">
                <span v-if="face.person_name" class="mr-2 mt-1">
                  <span style="background: #e5e5e5;
                    padding: 0px 6px;
                    border-radius: 13px;">
                    <b-icon icon="person-bounding-box" scale="1"></b-icon>
                    {{ face.person_name }}
                    <span v-b-tooltip.hover :title="'ค่า confidence'" class="small">({{
                      parseFloat((face.confidence * 100).toFixed(2))
                    }}%)</span></span></span>
              </span>
            </div>
          </div>
        </div>

        <div class="text-left ai-box my-2 px-2" v-if="datas && datas.ocr && username == 'adminatapy'"
          style="font-size: 15px;font-weight: 500;">
          <div v-for="(text, idx) in datas.ocr">
            <!-- {{ postDomain.ocr.face[].person_name /postDomain.ocr.face[].confidence >) }} -->
            <div v-if="text.text_sort && text.text_sort.length">
              <b-avatar size="18px" style="font-size: 12px;background-color:#8b8787;" class="mr-1">{{ idx
                + 1 }}
              </b-avatar>
              <b-icon icon="textarea-t" scale="1.3"></b-icon> OCR :
              {{ text.text_sort[0] }}
            </div>
            <div v-if="text.face">
              <span v-for="(face, idx) in text.face">
                <span v-if="face.confidence > 0.8" class="mr-2 mt-1">
                  <span style="background: #e5e5e5;
    padding: 0px 6px;
    border-radius: 13px;">
                    <b-icon icon="person-bounding-box" scale="1"></b-icon>
                    {{ face.person_name.replace("_", " ") }}
                    <span v-b-tooltip.hover :title="'ค่า confidence'" class="small">({{
                      parseFloat((face.confidence * 100).toFixed(2))
                    }}%)</span></span></span>
              </span>
            </div>
          </div>
        </div>
        <div v-if="
          datas &&
          datas.location &&
          datas.location.length
        " class="text-left ai-box my-2 px-2 text-small " style="font-size: 13px;font-weight: 500; color: #2c3e50;">
          <i class="fa fa-map-marker mr-1" aria-hidden="true" style="font-size: 15px;"></i>
          <span v-for="(geo, k) in filterNumbers(datas.location)" :key="k" class="mr-1" style="border: 1px solid #2c3e505e  ;padding: 0px 5px;display: inline-flex;text-align: center;
    border-radius: 33px;
">
            <!-- {{ geo.toString() }} -->
            <span v-if="geo.toString() && geo.toString().length == 2">
              {{ matchGeocode(geo).name_th }}
            </span>
            <span v-if="geo.toString() && geo.toString().length == 4">
              {{ matchGeocode(geo.toString().substring(0, 2)).name_th }}
              {{
                geo.toString().substring(0, 2) == "10"
                  ? " ข." + matchGeocode(geo).name_th
                  : " อ." + matchGeocode(geo).name_th
              }}
            </span>
            <span v-if="geo.toString() && geo.toString().length == 6">
              {{ matchGeocode(geo.toString().substring(0, 2)).name_th }}
              {{
                geo.toString().substring(0, 2) == "10"
                  ? " ข." + matchGeocode(geo).name_th
                  : " อ." + matchGeocode(geo).name_th
              }}
              {{
                geo.toString().substring(0, 2) == "10"
                  ? "แขวง" + matchGeocode(geo).name_th
                  : "ต." + matchGeocode(geo).name_th
              }}
            </span>
          </span>
        </div>
        <div class="text-left ai-box my-2 px-2" v-if="datas && datas.face_detect && username == 'adminatapy'"
          style="font-size: 15px;font-weight: 500;">
          <div v-if="datas.face_detect && datas.person_name && datas.person_name.length">
            <span v-for="(face, idx) in datas.person_name">
              <span class="mr-2 mt-1" v-if="face">
                <span style="background: #e5e5e5;
    padding: 0px 6px;
    border-radius: 13px;">
                  <b-icon icon="person-bounding-box" scale="1"></b-icon>
                  {{ face }}
                </span></span>
            </span>
          </div>
        </div>
        <template #footer>
          <div class="comment-img text-left md-font">
            <!------------- engages-------------- -->
            <span v-b-tooltip.hover title="Engagement" v-if="datas.source == 'pantip'">
              <span style="font-size:14px;">Engages </span>
              {{ (datas.engagement + datas.comments_count) | numFormat }}
            </span>

            <span v-b-tooltip.hover title="Engagement" v-else>
              <span style="font-size:14px;">Engages </span>{{ datas.engagement | numFormat }}
            </span>

            <!-- popover user comment -->
            <popover :name="'foo' + k" id="foo" v-if="
              datas.source !== 'facebook' &&
              datas.source !== 'youtube' &&
              datas.source !== 'twitter'
            ">
              <div class="text-center">
                <i class="fa fa-user-circle" aria-hidden="true"></i>
                <div id="bg-user">account name</div>
              </div>

              <div v-if="datas.comment == ''" class="text-center">
                ไม่มีลิสต์รายชื่อ account
              </div>
              <div v-if="datas.comment == undefined" class="text-center">
                ไม่มีลิสต์รายชื่อ account
              </div>
              <!-- <div v-for=" comment_tw in datas.retweet_obj"><span >{{comment_tw}}</span></div> -->
              <div id="scroll">
                <div v-if="datas.comment !== undefined">
                  <!-- <div v-if="datas.source == 'twitter'">
                        <i class="fas fa-comment"></i> reply
                        | <i class="fal fa-retweet"></i> retweet</div>   -->
                  <div v-for="comment in datas.comment" :key="comment">
                    <!-- fb -->
                    <a id="user-link" v-if="datas.source === 'facebook'"
                      v-bind:href="'https://facebook.com//' + comment.id" target="_blank">
                      <i class="fa fa-user-circle-o" />
                      {{ comment.display_name }}</a>

                    <!-- tw -->
                    <span v-if="datas.source === 'twitter'">
                      <span v-if="comment.post_type == 'reply'">
                        <a id="user-link" v-bind:href="'https://twitter.com/' + comment.account_name
                          " target="_blank">
                          <i class="fas fa-comment"></i>
                          <img v-bind:src="comment.photo" id="img-user" />
                          {{ comment.account_name }}</a>
                      </span>
                      <span v-if="comment.post_type == 'retweet'">
                        <a id="user-link" v-bind:href="'https://twitter.com/' + comment.account_name
                          " target="_blank">
                          <i class="fal fa-retweet"></i>
                          <img v-bind:src="comment.photo" id="img-user" />
                          {{ comment.account_name }}</a>
                      </span>
                    </span>
                    <!-- news -->
                    <!-- <a id ="user-link" v-if="datas.source === 'news'" v-bind:href="'https://pantip.com//' + comment.account_name" target="_blank">
                      <i class="fa fa-user-circle-o"/> {{comment.account_name}}</a> -->

                    <!-- IG -->
                    <a id="user-link" v-if="datas.source === 'instagram'" v-bind:href="'https://www.instagram.com//' + comment.owner.id
                      " target="_blank">
                      <img v-bind:src="comment.owner.profile_pic_url" id="img-user" />
                      {{ comment.owner.username }}</a>

                    <!-- pt -->
                    <a id="user-link" v-if="datas.source === 'pantip'" v-bind:href="'https://pantip.com//profile/' + comment.username
                      " target="_blank">
                      <img v-bind:src="comment.photo" id="img-user" />
                      {{ comment.username }}</a>
                    <!-- yt -->
                    <a id="user-link" v-if="datas.source === 'youtube'" v-bind:href="'https://www.youtube.com/' + comment.author_link
                      " target="_blank">
                      <img v-bind:src="comment.photo" id="img-user" />
                      {{ comment.author }}</a>
                  </div>
                </div>

                <!-- <div v-if="datas.comment==''" class="text-center">ไม่มีลิสต์รายชื่อ account</div> -->
              </div>
            </popover>
            <span id="box-reaction" v-b-tooltip.hover title="Comments" :aria-expanded="visible ? 'true' : 'false'"
              style="cursor: pointer" v-b-toggle="'btn' + offset + k">
              <i class="fas fa-comment"> </i>
              <span class="md-font" v-if="datas.comments_count && datas.source == 'news'">
                {{ datas.comments.comments.length | numFormat }}&nbsp;
              </span>
              <span v-else class="md-font">
                {{ datas.comments_count | numFormat }}&nbsp;</span>
              <!-- <span  class="md-font" v-if="datas.comments_count==''&&datas.source == 'twitter'"> 0 </span> -->
            </span>

            <!-- twitter -->
            <span v-if="datas.source !== 'facebook' && datas.source !== 'youtube'">
              <span v-if="datas.retweets_count !== '0' && datas.retweets_count" id="box-reaction" v-b-tooltip.hover
                title="Retweet">
                <i class="fal fa-retweet"></i>
                {{ datas.retweets_count | numFormat }}
              </span>
              <span v-if="datas.likes_count !== '0' && datas.likes_count" id="box-reaction" v-b-tooltip.hover
                title="Like">
                <i class="fa fa-heart"></i>
                {{ datas.likes_count | numFormat }}
              </span>
              <span v-if="datas.shares_count !== '0' && datas.shares_count" id="box-reaction" v-b-tooltip.hover
                title="Share">
                <i class="fa fa-share"></i>
                {{ datas.shares_count | numFormat }}
              </span>
              <span v-if="datas.views_count !== '0' && datas.views_count" id="box-reaction" v-b-tooltip.hover
                title="View">
                <i class="fas fa-eye"></i>
                {{ datas.views_count | numFormat }}
              </span>
            </span>
            <!-- share blockdit -->
            <span v-if="datas.source == 'blockdit' && datas.engagement">
              <span id="box-reaction" v-b-tooltip.hover title="Share">
                <i class="fa fa-share"></i>
                <span class="md-font">
                  {{ datas.engagement | numFormat }}
                </span>
              </span>
            </span>
            <!-- reaction-->
            <span v-if="datas.reaction">
              <span v-if="datas.reaction != ''">
                <!-- pt -->
                <span v-if="datas.reaction.Good">
                  <span v-if="datas.reaction.Good !== '0'" id="box-reaction" v-b-tooltip.hover title="Good Content">
                    <i class="fa fa-plus"></i>
                    <span class="md-font">
                      {{ datas.reaction.Good | numFormat }}
                    </span>
                  </span>
                </span>
                <span v-if="datas.reaction.Horror">
                  <span v-if="datas.reaction.Horror !== '0'" id="box-reaction" v-b-tooltip.hover title="Horror">
                    <img v-if="datas.reaction.Horror !== '0'" src="@/assets/horror.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.Horror !== '0'">
                      {{ datas.reaction.Horror | numFormat }}
                    </span>
                  </span>
                </span>
                <!-- pt -->
                <!-- fb -->
                <span v-if="datas.reaction.Likes">
                  <span v-if="datas.reaction.Likes !== '0'" id="box-reaction" v-b-tooltip.hover title="Like">
                    <img v-if="datas.reaction.Likes !== '0'" src="@/assets/fb_like.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.Likes !== '0'">
                      {{ datas.reaction.Likes | numFormat }}
                    </span>
                  </span>
                </span>

                <span v-if="datas.reaction.like">
                  <span v-if="datas.reaction.like !== '0'" id="box-reaction" v-b-tooltip.hover title="Like">
                    <img v-if="datas.reaction.like !== '0'" src="@/assets/fb_like.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.like !== '0'">
                      {{ datas.reaction.like | numFormat }}
                    </span>
                  </span></span>
                <span v-if="datas.reaction.shares">
                  <span v-if="datas.reaction.shares !== '0'" id="box-reaction" v-b-tooltip.hover title="Share">
                    <i class="fa fa-share" v-if="datas.reaction.shares !== '0'"></i>
                    <span class="md-font" v-if="datas.reaction.shares !== '0'">
                      {{ datas.reaction.shares | numFormat }}
                    </span>
                  </span>
                </span>

                <span v-if="datas.reaction.share">
                  <span v-if="datas.reaction.share !== '0'" id="box-reaction" v-b-tooltip.hover title="Share">
                    <i class="fa fa-share" v-if="datas.reaction.share !== '0'"></i>
                    <span class="md-font" v-if="datas.reaction.share !== '0'">
                      {{ datas.reaction.share | numFormat }}
                    </span>
                  </span>
                </span>

                <span v-if="datas.reaction.Love">
                  <span v-if="datas.reaction.Love !== '0'" id="box-reaction" v-b-tooltip.hover title="Love">
                    <img v-if="datas.reaction.Love !== '0'" src="@/assets/love.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.Love !== '0'">
                      {{ datas.reaction.Love | numFormat }}
                    </span>
                  </span>
                </span>

                <span v-if="datas.reaction.Wow">
                  <span v-if="datas.reaction.Wow !== '0'" id="box-reaction" v-b-tooltip.hover title="Wow">
                    <img v-if="datas.reaction.Wow !== '0'" src="@/assets/wow.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.Wow !== '0'">
                      {{ datas.reaction.Wow | numFormat }}
                    </span>
                  </span>
                </span>

                <span v-if="datas.reaction.Haha">
                  <span v-if="datas.reaction.Haha !== '0'" id="box-reaction" v-b-tooltip.hover title="Haha">
                    <img v-if="datas.reaction.Haha !== '0'" src="@/assets/haha.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.Haha !== '0'">
                      {{ datas.reaction.Haha | numFormat }}
                    </span>
                  </span>
                </span>

                <span v-if="datas.reaction.Sad">
                  <span v-if="datas.reaction.Sad !== '0'" id="box-reaction" v-b-tooltip.hover title="Sad">
                    <img v-if="datas.reaction.Sad !== '0'" src="@/assets/sad.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.Sad !== '0'">
                      {{ datas.reaction.Sad | numFormat }}
                    </span>
                  </span>
                </span>

                <span v-if="datas.reaction.Angry">
                  <span v-if="datas.reaction.Angry !== '0'" id="box-reaction" v-b-tooltip.hover title="Angry">
                    <img v-if="datas.reaction.Angry !== '0'" src="@/assets/angry.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.Angry !== '0'">
                      {{ datas.reaction.Angry | numFormat }}
                    </span>
                  </span>
                </span>
                <span v-if="datas.reaction.Hug">
                  <span v-if="datas.reaction.Hug !== '0'" id="box-reaction" v-b-tooltip.hover title="Hug">
                    <img v-if="datas.reaction.Hug !== '0'" src="@/assets/hug.png" id="emoji" />
                    <span class="md-font" v-if="datas.reaction.Hug !== '0'">
                      {{ datas.reaction.Hug | numFormat }}
                    </span>
                  </span>
                </span>

                <!-- yt -->
                <span v-if="datas.reaction.view_count" v-b-tooltip.hover title="Views">
                  <span v-if="datas.reaction.view_count !== ''" id="box-reaction"><i class="fas fa-eye"></i>
                    <span class="md-font" v-if="datas.reaction.view_count !== ''">
                      {{ datas.reaction.view_count | numFormat }}
                    </span>
                  </span>
                </span>
                <span v-if="datas.reaction.likes">
                  <span v-if="datas.reaction.likes !== '0'" id="box-reaction" v-b-tooltip.hover title="Like">
                    <img v-if="datas.reaction.likes !== '0'" /><i class="far fa-thumbs-up"></i>
                    <span class="md-font" v-if="datas.reaction.likes !== '0'">
                      {{ datas.reaction.likes | numFormat }}
                    </span>
                  </span>
                </span>

                <span v-if="datas.reaction.dislikes">
                  <span v-if="datas.reaction.dislikes !== '0'" id="box-reaction" v-b-tooltip.hover title="Dislike">
                    <i class="far fa-thumbs-down"></i>
                    <span class="md-font">
                      {{ datas.reaction.dislikes | numFormat }}
                    </span>
                  </span>
                </span>
                <!-- end yt -->
              </span>
            </span>

            <!-- comment content -->
            <b-collapse :id="'btn' + offset + k" class="mt-2" v-if="datas.comments && datas.comments.length">
              <b-card id="cmt-card" class="text-left">
                <span v-if="datas.source == 'news' && datas.comments">
                  <div v-for="(cmtn, inx) in datas.comments.comments" :key="inx">
                    <b-row>
                      <b-col lg="1">
                        <img :src="cmtn.pictureUrl" id="img-cmt" @error="setAltImg" />
                      </b-col>
                      <b-col lg="11">
                        <div>
                          <span class="bold">{{ cmtn.displayName }}</span>
                          <span class="font-weight-light" id="cmt-time">{{
                            cmtn.time
                          }}</span>
                        </div>

                        <div v-for="(text, i) in cmtn.contents" :key="i">
                          {{ text.extData.content }}
                        </div>
                      </b-col>
                    </b-row>
                    <hr />
                  </div>
                </span>
                <span v-else>
                  <div v-for="(cmt, i) in datas.comments" :key="i">
                    <b-row>
                      <b-col lg="1">
                        <a :href="'https://www.youtube.com/' + cmt.author_link" target="_blank"
                          v-if="datas.source == 'youtube'">
                          <img :src="cmt.photo" id="img-cmt" v-if="cmt.photo" />
                          <b-avatar v-else loading="lazy" v-else style="height: 32px;"></b-avatar>
                        </a>
                        <a :href="cmt.url" target="_blank" v-else>
                          <img :src="cmt.photo" id="img-cmt" v-bind:href="cmt.url" v-if="cmt.photo" />
                          <b-avatar v-else loading="lazy" v-else style="height: 32px;"></b-avatar>
                        </a>

                        <!-- <img v-if="datas.source=='news'" :src="cmt.comments.pictureUrl" id="img-cmt"> -->
                        <span> </span>
                      </b-col>
                      <b-col lg="11">
                        <div>
                          <a :href="'https://www.youtube.com/' + cmt.author_link" target="_blank"
                            v-if="datas.source == 'youtube'">
                            <span v-if="datas.source == 'youtube'" class="bold">
                              {{ cmt.author }}</span></a>
                          <a :href="cmt.url" target="_blank" v-else>
                            <span class="bold"> {{ cmt.username }}</span></a>
                          <span v-if="datas.source == 'youtube' && cmt.time" class="font-weight-light" id="cmt-time">{{
                            cmt.time.split("T")[0] }} |
                            {{ cmt.time.split("T")[1] }}</span>
                          <span v-else class="font-weight-light" id="cmt-time">{{
                            cmt.time
                          }}</span>
                        </div>

                        <div v-if="datas.source == 'youtube'" class="font-weight-light">
                          {{ cmt.text }}
                        </div>
                        <div v-else class="font-weight-light">
                          {{ cmt.content }}
                        </div>
                      </b-col>
                    </b-row>
                    <hr />
                  </div>
                </span>
              </b-card>
            </b-collapse>
          </div>
        </template>
      </b-card>
    </div>
    <ul class="pagination" v-if="datacount != 0">
      <li class="page-item" v-for="pageNumber in totalPages" :key="pageNumber">
        <span v-if="
          Math.abs(pageNumber - currentPage) < 3 ||
          pageNumber == totalPages ||
          pageNumber == 1
        ">
          <a class="page-link md-font" v-bind:key="pageNumber"  @click="setPage(pageNumber)" :class="{
            current: currentPage === pageNumber,
            last:
              pageNumber == totalPages &&
              Math.abs(pageNumber - currentPage) > 3,
            first: pageNumber == 1 && Math.abs(pageNumber - currentPage) > 3,
          }">{{ pageNumber }}</a></span>
      </li>
    </ul>
    <input type="number" class="form-control md-font" v-model="gotopage" id="setpage" style="width: 150px"
      v-if="datacount != 0" />

    <span v-if="datacount != 0">
      <button type="button" class="btn btn-default" @click="page()">
        <span id="submit" class="md-font">Go to Page</span>
      </button>
    </span>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import Highlighter from "vue-highlight-words";
import VueGallerySlideshow from "vue-gallery-slideshow";
import moment from "moment";
import "@justinribeiro/lite-tiktok";
import { API_V2_URL } from "@/common/config";
import provinces from "@/components/map/provinces.json";
import districts from "@/components/map/districts.json";
import subdistricts from "@/components/map/subdistricts.json";
import SentimentBar from "@/components/wordcloudnew/SentimentBar.vue";
import PlatformBarChart from "@/components/chart/PlatformBarChart.vue";
import Vue from "vue";

Vue.filter("shortNumber", function (value, digits = 1) {
  const n = Number(value);
  if (!isFinite(n)) return "0";

  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";

  const fmt = (x) => {
    // ตัด .0 ทิ้ง เช่น 1.0k => 1k
    const s = x.toFixed(digits);
    return s.replace(/\.0+$|(\.\d*[1-9])0+$/, "$1");
  };

  if (abs < 1000) return sign + abs.toLocaleString("en-US");
  if (abs < 1e6) return sign + fmt(abs / 1e3) + "k";
  if (abs < 1e9) return sign + fmt(abs / 1e6) + "M";
  if (abs < 1e12) return sign + fmt(abs / 1e9) + "B";
  return sign + fmt(abs / 1e12) + "T";
});

// ใช้สำหรับ tooltip (จำนวนเต็มพร้อม comma)
Vue.filter("intFormat", function (value) {
  const n = Number(value);
  if (!isFinite(n)) return "0";
  return Math.round(n).toLocaleString("en-US");
});

export default {
  props: {
    checkpost: {
      type: Boolean,
    },
    querySearch: { type: String, default: "" },
    social: {
      type: String,
      default:
        "news,twitter,facebook,youtube,tiktok,blockdit,instagram,pantip,threads",
    },
    type: {
      type: String,
      default: "daily",
    },
    sentimentWord: {
      type: Number,
    },
  },
  watch: {
    querySearch: {
      immediate: true,
      handler(val) {
        // ✅ ยิงครั้งแรกแน่นอนตอน component ถูกสร้าง
        this.localQuery = (val || "").trim();
        this.offset = 0;
        this.currentPage = 1;

        // ถ้าไม่มีคำ ไม่ต้องยิง
        if (!this.localQuery) return;

        this.apiSpotNewsPost(0);
      }
    }
  },
  data() {
    return {
      datacountchart: 0,
      localQuery: "",
      showFull: false,
      topics: "",
      datachart: {},
      sliding: null,
      slide: 0,
      selectIndex: 0,
      platform: null,
      load: true,
      datacount: 0,
      dataIssue: [],
      objId: "",
      arrword: [],
      myStyle: {
        backgroundColor: "#f7dca2",
      },
      checked: true,
      andkey: [],
      heightword: [],
      visible: false,
      index: null,
      dataPhoto: [],
      currentImageFather: null,
      overlayActiveFather: false,
      start_date: "",
      end_date: "",
      valueDate: "",
      offset: 0,
      username: "",
      btnPosStyle: {
        backgroundColor: "#54c69d",
        color: "#ffffff",
        borderColor: "#54c69d",
      },
      btnNeuStyle: {
        backgroundColor: "#3a86ad",
        color: "#ffffff",
        borderColor: "#3a86ad",
      },
      btnNegStyle: {
        backgroundColor: "#f7776a",
        color: "#ffffff",
        borderColor: "#f7776a",
      },
      imageLink: this.$hostname + "/static/Account/images/snapshot/",
      currentPage: 1,
      itemsPerPage: 10,
      resultCount: 0,
      length: 5,
      //length:5, //change this for items per page too
      sort: "",
      count: 0,
      has_next: "",
      gotopage: "",
      img: "",
      imgtw: require("@/assets/Twitter.png"),
      imgfb: require("@/assets/Facebook.png"),
      imgpt: require("@/assets/board.png"),
      imgig: require("@/assets/Instagram.png"),
      imgnw: require("@/assets/News.png"),
      imgyt: require("@/assets/Youtube.png"),
      imgbd: require("@/assets/Blockdit.png"),
      user: require("@/assets/user.svg"),
      selectedStm: this.status,
      selected: [1, 0, -1],
      selectedSort: "",
      select_social:
        "news,twitter,facebook,youtube,tiktok,blockdit,instagram,pantip,threads",
      itemSocial: [
        {
          text: "All Platform",
          value:
            "news,twitter,facebook,youtube,tiktok,blockdit,instagram,pantip,threads",
        },
        { text: "facebook", value: "facebook" },
        { text: "X", value: "twitter" },
        { text: "board", value: "pantip" },
        // { text: "news", value: "news" },
        { text: "youtube", value: "youtube" },
        { text: "instagram", value: "instagram" },
        { text: "blockdit", value: "blockdit" },
        { text: "tiktok", value: "tiktok" },
        { text: "threads", value: "threads" },
      ],

      options: [
        { text: "Positive", value: "1" },
        { text: "Neutral", value: "0" },
        { text: "Negative", value: "-1" },
        { text: "ทั้งหมด", value: [1, 0, -1] },
      ],
      optionSort: [
        { value: "", text: " โพสต์ล่าสุด" },
        { value: "descend", text: "โพสต์เริ่มต้น" },
        { value: "engagement", text: "Engagement" },
      ],
    };
  },
  components: {
    Highlighter,
    VueGallerySlideshow,
    SentimentBar,
    PlatformBarChart,

  },
  computed: {
    ...mapGetters(["getClickDomain", "getClickDomainId", "getSdateDm", "getEdateDm", "getArrDate"]),

    paginate() {
      const start = (this.currentPage - 1) * this.itemsPerPage;
      const end = start + this.itemsPerPage;

      return Array.isArray(this.dataIssue)
        ? this.dataIssue.slice(start, end)
        : [];
    },
    totalPages() {
      return Math.ceil(this.datacount / this.itemsPerPage); // คำนวณจำนวนหน้าทั้งหมด
    },
  },
  methods: {
    setDateRange() {
      if (!this.startd || !this.endd) {
        const today = moment(new Date()).format().slice(0, 10);

        this.start_date = today + "T00:00:00";
        this.end_date = today + "T23:59:59";
      } else {
        this.start_date = this.startd + "T00:00:00";
        this.end_date = this.endd + "T23:59:59";
      }
    },
    fetchObjectCount() {
      this.$store.commit('setshowStatWC', true)
      // ---- route query ----
      const startQ = this.$route.query.start;
      const endQ = this.$route.query.end;

      // fallback วันปัจจุบัน
      const today = moment(new Date()).format("YYYY-MM-DD");
      const start = (startQ && String(startQ).trim()
        ? String(startQ).trim()
        : `${today}T00:00:00`
      );
      const end = (endQ && String(endQ).trim()
        ? String(endQ).trim()
        : `${today}T23:59:59`
      );

      // source: ใช้ตัวที่เลือกอยู่ หรือ default
      // (API ตัวอย่างใช้ source=threads)
      const source = this.select_social || "threads";

      // keyword / hashtag แบบเดียวกับ apiSpotNewsPost
      const rawKeyword = (this.localQuery || "").trim();
      const isHashtag = rawKeyword.startsWith("#") && rawKeyword.length > 1;
      const keyword = isHashtag ? "" : rawKeyword;
      const hashtag = isHashtag ? rawKeyword.replace(/^#/, "") : "";

      // domain: ถ้าคุณมี "ชื่อโดเมน" เก็บไว้ใน query (เช่น this.$route.query.domain)
      // ไม่งั้นอาจ fallback เป็น domain_id (แต่ API นี้น่าจะอยากได้ชื่อ)
      const domain = this.$route.query.domain_id || ""; // ✅ แนะนำให้ส่ง "ชื่อ domain"
      const monitor = this.$route.query.monitor || "";

      // ---- call API ----
      const url = "https://api2.cognizata.com/api/v2/userposts/getSentimentStat";

      const params = {
        source,
        start,
        end,
      };

      if (domain) params.domain_id = domain;
      if (monitor) params.monitor = monitor;
      // ✅ เลือกส่ง param ให้ถูก
      if (hashtag) params.hashtags = hashtag;
      else if (keyword) params.querySearch = keyword;

      this.axios
        .get(url, {
          params,
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
            "Content-Type": "application/json",
          },
        })
        .then((response) => {
          // ---- normalize output ----
          const d = response.data?.data || response.data[0];
          // ทำให้ datachart มีหน้าตาเหมือนเดิม (มี name, count, positive, neutral, negative)
          this.datachart = {
            name: rawKeyword || d?.name || "",      // หรือจะใช้ domain ก็ได้
            count: d?.totalPost ?? 0,
            positive: d?.positiveSentiment ?? 0,
            neutral: d?.neutralSentiment ?? 0,
            negative: d?.negativeSentiment ?? 0,
          };

          // datacount ที่เอาไปทำ pagination
          this.datacountchart = this.datachart.count || 0;

          // platform (ถ้า API ส่ง breakdown มา)
          this.platform = d?.platform || d || {};
          this.$store.commit('setshowStatWC', false)

        })
        .catch((error) => {
          this.$store.commit('setshowStatWC', false)
          console.error("Error fetching sentiment stat:", error);
        });
    },
    onSlideStart(slide) {
      this.sliding = true;
    },
    onSlideEnd(slide) {
      this.sliding = false;
    },
    scrollLeft() {
      const slider = this.$refs.slider;
      slider.scrollLeft -= 300; // เลื่อนซ้าย 300px
    },
    scrollRight() {
      const slider = this.$refs.slider;
      slider.scrollLeft += 300; // เลื่อนขวา 300px
    },
    filterNumbers(numbers) {
      // ✅ PRE-PROCESS
      const filtered = [
        ...new Set(
          (numbers || [])
            .map(n => String(n).trim())
            // ❌ ตัด 7 หลักทิ้ง
            .filter(s => /^\d+$/.test(s) && s.length !== 7)
        )
      ].sort((a, b) => a.length - b.length);

      // ✅ LOGIC เดิม
      for (let i = 0; i < filtered.length; i++) {
        for (let j = i + 1; j < filtered.length; j++) {
          const num1 = filtered[i];
          const num2 = filtered[j];

          // If num1 matches the start of num2, remove num1
          if (num2.startsWith(num1)) {
            filtered.splice(i, 1);
            i--;
            break;
          }
        }
      }

      return filtered;
    },

    matchGeocode(geocode) {
      const geocodeStr = geocode.toString(); // แปลง geocode เป็น string
      let found = null;

      // กรองข้อมูลตามความยาว geocode
      if (geocodeStr.length === 2) {
        found = provinces[geocodeStr];
      } else if (geocodeStr.length === 4) {
        found = districts[geocodeStr];
      } else if (geocodeStr.length === 6) {
        found = subdistricts[geocodeStr];
      }

      // Return the found location or a fallback message
      return found || { geocode: geocodeStr, message: "ไม่พบข้อมูล" };
    },
    highlightText(full_text) {


      var word = [];
      if (this.checked) {
        word.push(...[this.localQuery]);
        if (this.andkey.length) {
          this.andkey.forEach(function (key) {

            if (
              key.length == 2 &&
              full_text.includes(key[0]) &&
              full_text.includes(key[1])
            ) {


              word.push(...key);
            }

            if (
              key.length == 3 &&
              full_text.includes(key[0]) &&
              full_text.includes(key[1]) &&
              full_text.includes(key[2])
            ) {
              word.push(...key);
            }
            if (
              key.length == 4 &&
              full_text.includes(key[0]) &&
              full_text.includes(key[1]) &&
              full_text.includes(key[2]) &&
              full_text.includes(key[3])
            ) {
              word.push(...key);
            }
          });


        }
      }
      return word;
    },
    selectSort() {
      this.offset = 0;
      this.currentPage = 1;
      this.page = 0;
      this.apiSpotNewsPost();
    },
    selectSentiment() {
      this.offset = 0;
      this.currentPage = 1;
      this.page = 0;
      this.apiSpotNewsPost();
    },

    // highlightText(key) {
    //   var word = [];
    //   if (this.checked) {
    //     word = key;
    //   } else {
    //     word = [];
    //   }
    //   return word;
    // },

    onClick(i, data) {
      // console.log(data);
      this.index = i;
      this.dataPhoto = data;
    },
    clickImage(index) {
      this.currentImageFather = index;
      this.overlayActiveFather = true;
    },

    pageApi(sort, offset, querySearch) {
      offset = this.offset;
      // console.log('offset',offset);

      sort = this.sort;
      // querySearch = this.getQuerySearch;
      this.apiSpotNewsPost(offset);

    },
    page() {
      var pageNumber;
      if (
        parseInt(this.gotopage) > Math.ceil(this.datacount / 10) ||
        this.gotopage.includes("-")
      ) {
        alert("Wrong number");
        pageNumber = 1;
      } else {
        pageNumber = parseInt(this.gotopage);
      }
      this.setPage(pageNumber);
      this.gotopage = "";
      // console.log(pageNumber);
    },
    setPage(page) {
      this.currentPage = page;
      this.offset = (page - 1) * this.itemsPerPage; // ✅ คำนวณ offset จากหน้า
      this.pageApi(); // เรียก API ใหม่หลังเปลี่ยนหน้า
    }
    ,
    tabactive() {
      document.getElementById("eltab1").style.borderColor = "#fed16e";
      document.getElementById("eltab2").style.borderColor = "#4c412b";
      document.getElementById("eltab3").style.borderColor = "#4c412b";
      this.offset = 0;
      this.sort = "";
      this.currentPage = 1;
      this.pageApi(this.sort, this.offset, this.querySearch);
      // this.offset=0
      // this.$store.dispatch("fetchSentimentPost",{type:this.getDateChoice,source:this.social,sentiment:this.status,sort_by:"",offset:this.offset});
    },
    tab2() {
      document.getElementById("eltab1").style.borderColor = "#4c412b";
      document.getElementById("eltab3").style.borderColor = "#4c412b";
      document.getElementById("eltab2").style.borderColor = "#fed16e";
      this.offset = 0;
      this.currentPage = 1;
      this.sort = "descend";
      this.pageApi(this.sort, this.offset, this.querySearch);
      // this.offset=0
      // this.$store.dispatch("fetchSentimentPost",{type:this.getDateChoice,source:this.social,sentiment:this.status,sort_by:'descend',offset:this.offset});
    },
    tab3() {
      document.getElementById("eltab1").style.borderColor = "#4c412b";
      document.getElementById("eltab2").style.borderColor = "#4c412b";
      document.getElementById("eltab3").style.borderColor = "#fed16e";
      this.offset = 0;
      this.currentPage = 1;
      this.sort = "engagement";
      this.pageApi(this.sort, this.offset, this.querySearch);
      //   this.offset=0
      // this.$store.dispatch("fetchSentimentPost",{type:this.getDateChoice,source:this.social,sentiment:this.status,sort_by:'engagement',offset:this.offset});
    },
    getTheSelected(k, v, uid) {
      var err;
      if (v == 1) {
        err = "Positive";
      } else if (v == 0) {
        err = "Neutral";
      } else {
        err = "Negative";
      }
      this.$confirm("คุณต้องการเปลี่ยน Sentiment เป็น " + err + " ?").then(
        () => {
          const encoded = encodeURI(uid);
          var _this = this;
          var config = {
            method: "get",
            url:
              "https://api2.cognizata.com/api/v2/userposts/change_sentiment_word?uid=" +
              encoded +
              "&sentiment=" +
              v,
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
              "Content-Type": "application/json",
            },
          };
          this.axios(config)
            .then(function (response) {
              console.log(response);
              let se = _this.selected.toLocaleString();
              if (se == "1,0,-1") {
                if (v == 1) {
                  _this.dataIssue[k].sentiment = 1;
                  _this.dataIssue[k].user_sentiment[_this.objId] = 1;
                } else if (v == 0) {
                  _this.dataIssue[k].sentiment = 0;
                  _this.dataIssue[k].user_sentiment[_this.objId] = 0;
                } else {
                  _this.dataIssue[k].sentiment = -1;
                  _this.dataIssue[k].user_sentiment[_this.objId] = -1;
                }
              } else {
                console.log("in 1");
                if (v == _this.selected) {
                  console.log("in 11");
                  _this.dataIssue[k].sentiment = v;
                  _this.dataIssue[k].user_sentiment[_this.objId] = v;
                } else {
                  console.log("in 12");
                  _this.dataIssue.splice(k, 1);
                }
              }
            })
            .catch(function (response) {
              console.log("errrrrrr", response.message);
            });
          // if (v !== this.dataIssue[k].sentiment) {
          //   this.$store.dispatch("editSentimentPost", {
          //     sentiment: v,
          //     uid: uid,
          //   });
          //   if (this.selected == "") {
          //     if (v == 1) {
          //       this.dataIssue[k].sentiment = 1;
          //     } else if (v == 0) {
          //       this.dataIssue[k].sentiment = 0;
          //     } else {
          //       this.dataIssue[k].sentiment = -1;
          //     }
          //   } else {
          //     this.dataIssue.splice(k, 1);
          //   }
          //   // this.dataIssue.splice(k, 1);
          //   this.$fire({
          //     title: "แก้ไขสำเร็จ",
          //     type: "success",
          //     showConfirmButton: false,
          //     timer: 1000,
          //   });
          // } else {
          //   this.$alert("Sentiment เป็น " + err + " แล้ว!").then(() => {});
          // }
        }
      );
    },
    apiSpotNewsPost(offset) {
      this.datacount = 0
      this.dataIssue = []
      this.fetchObjectCount()
      this.load = true;

      // ------------------------
      // 1) keyword / hashtag
      // ------------------------
      const rawKeyword = (this.localQuery || "").trim();
      const isHashtag = rawKeyword.startsWith("#") && rawKeyword.length > 1;

      // ตัด # ออกก่อนส่ง (backend ส่วนใหญ่อยากได้แบบไม่มี #)
      const keyword = isHashtag ? "" : rawKeyword;
      const hashtag = isHashtag ? rawKeyword.replace(/^#/, "") : "";
      const monitor = this.$route.query.monitor || "";
      // ------------------------
      // 2) sentiment
      // ------------------------
      let stm = "";
      if (this.selected == "1,0,-1") { stm = ""; } else {
        stm = this.selected;
      }
      // ------------------------
      // 3) date fallback
      // ------------------------
      const startQ = this.$route.query.start;
      const endQ = this.$route.query.end;

      const today = moment(new Date()).format("YYYY-MM-DD");
      const start = (startQ && String(startQ).trim() ? String(startQ).trim() : today + "T00:00:00");
      const end = (endQ && String(endQ).trim() ? String(endQ).trim() : today + "T23:59:59");

      // ------------------------
      // 4) params
      // ------------------------
      const params = {
        sentiment: stm || "",
        source: this.select_social,
        sort_by: this.sort,
        limit: 10,
        start,
        end,
        offset,
      };
      if (monitor) params.monitor = monitor;
      // ✅ เลือกส่ง param ให้ถูก
      if (hashtag) {
        params.hashtags = hashtag;
      } else if (keyword) {
        params.querySearch = keyword;
      }
      if (this.$route.query.domain_id) {
        params.domain_id = this.$route.query.domain_id
      }
      // ------------------------
      // 5) request
      // ------------------------
      this.axios({
        method: "get",
        url: "https://api2.cognizata.com/api/v2/wordcloud/getSentimentdetailWordcloud",
        params,
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
          "Content-Type": "application/json",
        },
      })
        .then((response) => {
          if (response.data) {
            const post = response.data.data || [];
            this.datacount = response.data.count || 0;

            this.dataIssue = Array.isArray(post)
              ? post.map((p) => ({ ...p, read: true }))
              : [];
          }
          // this.check_sentiment_word(this.localQuery );
          this.load = false;
        })
        .catch((error) => {
          this.load = false;
          this.datacount = 0
          this.dataIssue = []
          console.error(error);
        });
    }
    ,
    check_sentiment_word(name) {
      const object_id = this.$route.query.object_id;
      let names = ""
      if (object_id) {
        names = "&name=" + name
      } else {
        names = "&subdomain=" + name
      }
      let domain_ids = "domain_id=" + this.$route.query.domain_id

      var config = {
        method: "get",
        url:
          "https://api2.cognizata.com/api/v2/object/check_sentiment_word?" + domain_ids
        ,
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
          "Content-Type": "application/json",
        },
      };

      this.axios(config)
        .then((response) => {
          this.arrword = response.data[0];
          // console.log(this.arrword);

          // ดำเนินการกับข้อมูลเมื่อ API เสร็จ
          var k = this.arrword?.Keywords;
          var ka = this.arrword?.and_keywords;
          let result = ka.map((key) => {
            return key.split("+");
          });
          this.andkey = result;
          this.heightword = k;
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
  },
  async mounted() {
    this.setDateRange();
    this.$emitter.on("sendKeyword", (val) => {
      // console.log('val', val);
      this.localQuery = val || "";
      this.offset = 0;
      this.currentPage = 1;
      this.apiSpotNewsPost(0);
    });
    // await this.apiSpotNewsPost();
    // await this.fetchObjectCount()
    //await this.check_sentiment_word()
  },
  beforeDestroy() {
    this.$emitter.off("sendKeyword"); // กันซ้ำ/กัน memory leak
  }
};
</script>

<style scoped>
.slider-item {
  flex: 0 0 auto;
  /* การ์ดแต่ละอันมีขนาดคงที่ */
  width: 25%;
  /* ขนาดการ์ด 4 ชิ้นใน 100% */
  flex-wrap: nowrap;
}

.slider-container {
  display: flex;
  align-items: center;
  flex-wrap: nowrap;
  border-radius: 15px;
}

.slider-button {
  background-color: #ffffff;
  color: rgb(112, 108, 108);
  border: none;
  padding: 10px 15px;
  margin: 0px 10px;
  cursor: pointer;
  border-radius: 15px;
  font-size: 20px;
}

.img-issue {
  width: 37px;
}

.card-platform {
  margin-bottom: 18px;
  border-radius: 15px;
  border: 0px solid rgba(0, 0, 0, .125) !important;
  box-shadow: 0 3px 5px 0 rgba(0, 0, 0, 0.2);
}

.box-hl {
  border-radius: 10px;
}

.highlight4 {
  background-color: #f7dca2;
  padding: 0 2px;
}

.all {
  background-color: #fed16e;
  color: white;
  width: 80px;
  padding: 7px;
}

p {
  margin-bottom: 0rem;
}

#picmore {
  background: #000000c7;
  color: white;
  padding: 5px 20px;
  font-size: 20px;
  margin: -44px;
  z-index: 1;
  position: relative;
  /* width: 68px; */
  float: right;
  cursor: pointer;
}

.col2 {
  column-count: 2;
  width: 504px;
  margin: auto;
}

.img-grid {
  width: 100%;
  height: 350px;
  object-fit: cover;
}

.images1 {
  width: 504px;
  height: 283.5px;
  object-fit: cover;
  background-size: contain;
  cursor: pointer;
  margin: 2px;
  border-radius: 16px;
  border: 1px solid #eaeff3;
}

.images2 {
  width: 253.5px;
  height: 283.5px;
  object-fit: cover;
  background-size: contain;
  cursor: pointer;
  margin: 2px;
  border-radius: 16px;
  border: 1px solid #eaeff3;
}

.images3 {
  width: 253.5px;
  height: 283.5px;
  object-fit: cover;
  background-size: contain;
  cursor: pointer;
  margin: 2px;
  border-radius: 16px;
  border: 1px solid #eaeff3;
}

.images3:nth-child(2) {
  height: 141.5px;
  position: absolute;
}

.images3:nth-child(3) {
  height: 141.5px;
  bottom: 23px;
  position: relative;
  bottom: -72px;
}

.images4 {
  width: 253.5px;
  height: 142px;
  object-fit: cover;
  background-size: contain;
  cursor: pointer;
  margin: 2px;
  border-radius: 16px;
  border: 1px solid #eaeff3;
}

.fa-external-link {
  margin-left: 5px;
  text-decoration: none;
  padding: 6px 6px;
  border-radius: 20px;
  color: #2c3e50;
}

.fa-external-link:hover {
  background: #ccc;
  color: #696d71;
  cursor: pointer;
}

#export-btn {
  margin: 0px 20px;
  color: #495057;
  background-color: #e9ecef;
  border-color: #e9ecef;
  border-radius: 9px;
  box-shadow: 0 2px 5px 0 rgb(0 0 0 / 20%);
}

#export-btn:hover {
  color: white;
  background-color: #495057;
  border-color: #495057;
}

a {
  color: #2c3e50;
  text-decoration: none;
  background-color: transparent;
}

.highlight-search {
  background-color: #fed16e;
  padding: 0 2px;
}

.highlight1 {
  background-color: #f7776a;
  padding: 0 2px;
}

.highlight2 {
  background-color: #54c69d;
  padding: 0 2px;
}

.highlight3 {
  background-color: #3a86ad;
  padding: 0 2px;
}

.form-control {
  background-color: #ede7dd;
  display: inline;
}

.pagination {
  margin-top: 30px;
  -webkit-box-pack: center;
  justify-content: center;
}

.current {
  color: white;
  background-color: #fed16e;
}

/* ul {
  padding: 0;
  list-style-type: none;
} */
li {
  display: inline;
  /* margin: 5px 5px; */
}

a.first::after {
  content: "...";
}

a.last::before {
  content: "...";
}

#btn-pos,
#btn-nue,
#btn-neg {
  color: #636465;
  background-color: #dddddd;
  border-color: #dddddd;
}

#btn-pos:hover {
  background-color: #cbc9c9;
  border-color: #cbc9c9;
  color: #636465;
}

#btn-neg:hover {
  background-color: #cbc9c9;
  border-color: #cbc9c9;
  color: #636465;
}

#btn-nue:hover {
  background-color: #cbc9c9;
  border-color: #cbc9c9;
  color: #636465;
}

.img-thumbnail {
  height: 240px;
  object-fit: cover;
  width: fit-content;
  cursor: pointer;
}

#box-reaction {
  background: #ddddddad;
  color: #2c3e50;
  border-radius: 7px;
  padding-right: 5px;
  padding-left: 5px;
  padding-top: 3px;
  padding-bottom: 3px;
  margin-left: 4px;
}

#post-comment {
  margin-left: 12px;
}

.modal {
  background-color: #ffffff00 !important;
}

.modal-header {
  border-bottom: none;
}

.modal-dialog {
  position: relative;
  width: auto;
  margin: 0;
  pointer-events: none;
  padding-top: 30px;
}

#img-popup {
  max-width: 90vw;
  height: auto;
  max-height: 90vh;
}

.close {
  float: right;
  font-size: 1.5rem;
  font-weight: bolder;
  line-height: 1;
  color: #ffffff;
  text-shadow: 0 1px 0 #616569;
  margin-left: 90%;
  opacity: 1;
  padding: 20px 0px;
}

.close span {
  background: #5453538c;
  padding: 5px 14px;
  border-radius: 50px;
}

.close span :hover {
  background: #545353c4;
}

.modal-dialog {
  max-width: none;
}

.modal-content {
  width: 100vw;
  margin: 0;
  background: transparent;
  border: none;
}

#img-user {
  width: 28px;
  border-radius: 50%;
  margin-bottom: 3px;
}

#scroll {
  min-height: auto;
  max-height: 200px;
  overflow: auto;
  overflow-x: hidden;
}

#user-link {
  color: #2c3e5a;
  margin-left: 45px;
  white-space: nowrap;
}

#user-link:hover {
  color: #2c3e50;
  background: #efebeb;
  padding-left: 10px;
  border-radius: 20px;
  padding-right: 10px;
  text-decoration: none;
  font-weight: bold;
}

#user-link:hover .fa-user-circle-o {
  font-weight: 900;
}

#bg-user {
  background: #ffffff;
  color: #2c3e5a;
  padding: 1px;
  padding-left: 10px;
  padding-right: 10px;
  width: 80%;
  border-radius: 6px;
  margin: auto;
  border: 1.5px solid;
  margin-bottom: 8px;
}

.fa-user-circle {
  font-size: 30px;
}

.fa-comment {
  font-size: 17px;
}

.fa-comment:hover {
  color: #fed16e;
}

.vue-popover.dropdown-position-top:before {
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-top: 6px solid #fff;
  bottom: -6px;
  left: calc(50% - 136px);
  filter: drop-shadow(0px 2px 2px rgba(52, 73, 94, 0.1));
}

#foo {
  width: 300px !important;
  z-index: 2 !important;
  left: unset !important;
  top: unset !important;
  bottom: 45px;
  max-height: 300px;
}

#bg-user {
  background: #ffffff;
  color: #2c3e5a;
  padding: 1px;
  padding-left: 10px;
  padding-right: 10px;
  width: 80%;
  border-radius: 6px;
  margin: auto;
  border: 1.5px solid;
  margin-bottom: 8px;
}

#emoji {
  width: 27px;
}

.comment-img {
  text-align: start;
}

.card-body {
  min-height: 6rem;
}

.card-text {
  text-align: justify;
  padding: 0px 10px;
}

.card-text:last-child {
  margin-top: 10px;
}

#tab-post {
  text-align: initial;
  padding-right: 50px;
  margin: auto;
}

.fa-facebook-official,
.fa-facebook-square {
  font-size: 42px;
  color: #4967aa;
  margin-right: 10px;
  vertical-align: middle;
}

.card-img {
  padding: 10px;
}

.card-footer {
  text-align: initial;
}

.user-img {
  width: 46px;
  z-index: 1;
  position: relative;
  border-radius: 50%;
  box-shadow: 2px 1px 4px #888888;
  height: 46px;
  display: inline-block;
  margin-left: 10px;
}

.social-img {
  width: 35px;
  margin-top: 6px;
  margin-left: -7px;
  height: 35px;
}

card-img,
.card-img-bottom,
.card-img-top {
  width: 100%;
  object-fit: cover;
}

.fa-sort-amount-down-alt {
  font-size: 28px;
  color: #4c412b;
}

.fa-sort-amount-down-alt:before {
  position: relative;
  bottom: -14px;
}

#all-eltab {
  border-bottom: 10px solid #4c412b;
}

#eltab1,
#eltab2,
#eltab3 {
  cursor: pointer;
  text-align: center;
  padding-right: 10px;
}

#eltab1 {
  outline-style: none;
  -webkit-box-shadow: none;
  box-shadow: none;
  border-color: transparent;
  border-bottom: 10px solid #fed16e;
}

#eltab2,
#eltab3 {
  outline-style: none;
  -webkit-box-shadow: none;
  box-shadow: none;
  border-color: transparent;
  border-bottom: 10px solid #4c412b;
}

#title-tab {
  padding-right: 5px;
}

#tab-view {
  text-align: end;
  /* padding-left: 50px; */
}

#tab-all {
  margin-top: 30px;
  margin-bottom: 30px;
}

@media only screen and (min-width: 0px) and (max-width: 1050px) {
  .col-sm-7 {
    flex: 0 0 100%;
    max-width: 100%;
  }

  .col-sm-5 {
    flex: 0 0 100%;
    max-width: 100%;
  }

  #tab-post {
    text-align: center;
    padding-right: 15px;
    margin-top: 20px;
  }

  #tab-view {
    text-align: center;
    padding-left: 0px;
  }

  #overflow-page {
    overflow: hidden;
  }

  #btn-sentiment>div {
    white-space: nowrap !important;
  }

  #btn-sentiment[data-v-1037f9aa] {
    right: -16%;
    position: relative;
    z-index: 1;
  }

  #text-date {
    white-space: nowrap;
  }
}

@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: portrait) {
  .all {
    padding: 10px !important;
  }
}

@media only screen and (min-width: 375px) and (max-width: 815px) {
  .card-text {
    font-size: 2vw;
  }
}

@media only screen and (min-width: 0px) and (max-width: 760px) {
  .title-news {
    font-size: 15px !important;
  }

  .bv-no-focus-ring {
    zoom: 80% !important;
  }

  .custom-control-inline {
    margin-right: 2px !important;
  }

  .card-platform .col-12 {
    padding-right: 2px !important;
    padding-left: 2px !important;
  }


  .box-hl {
    font-size: 16px;
    font-weight: 600;
  }

  #picmore {
    margin: -42px;
    margin-right: -1px;
  }

  .col2 {
    column-count: 2;
    width: 92%;
    margin: auto;
    column-gap: 4px;
  }

  .images4 {
    width: 100%;
  }

  .images3 {
    width: 46%;
  }

  .images2 {
    width: 46%;
  }

  .images1 {
    width: 92%;
    height: 283.5px;
  }
}

@media only screen and (min-width: 0px) and (max-width: 600px) {
  .card-text {
    font-size: 4vw;
  }

  .card-body {
    min-height: 8rem;
  }

  .card-text {
    padding: 0px 0px;
  }

  .social-img {
    width: 31px;
    margin-top: 6px;
    margin-left: -9px;
    height: 31px;
  }

  .user-img {
    width: 38px;
    height: 38px;
    margin-left: 10px;
  }

  .modal-body {
    padding: 0rem;
  }

  .close {
    padding: 20px 0px;
    margin-left: 84%;
  }

  #emoji {
    width: 20px;
  }

  #tab-view {
    padding-left: 0;
    text-align: center;
    margin-bottom: 31px;
  }

  #eltab1,
  #eltab2,
  #eltab3 {
    padding-right: 0px;
  }

  #all-eltab {
    font-size: 3.6vw;
  }

  .fa-sort-amount-down-alt:before {
    display: none;
  }

  #tab-post {
    margin-top: 25px;
    font-size: 3.6vw;
  }

  #tab-post {
    text-align: center;
    padding-right: 15px;
  }

  #tab-all {
    margin-top: 0px;
    margin-bottom: 0px;
  }

  #btn-sentiment {
    margin-top: 5px;
  }

  h1,
  .h1 {
    font-size: 1.5rem;
  }

  #content>div.container>div:nth-child(3)>div>header>div>div.btn-edit.col-sm>button {
    font-size: 3.5vw !important;
    font-weight: bold;
  }

  .social[data-v-00911447] {
    font-size: x-large;
  }

  #img-title {
    width: 50px;
    display: block;
    margin: auto;
    margin-bottom: 5px;
  }

  .all {
    width: 50px;
    display: block;
    margin: auto;
    margin-bottom: 5px;
  }
}
</style>
